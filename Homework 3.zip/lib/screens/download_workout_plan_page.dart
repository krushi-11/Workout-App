import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/models.dart';
import 'package:hive/hive.dart';

//this widget is for downloading the workout plan from internet through the json file
class DownloadWorkoutPage extends StatefulWidget {
  const DownloadWorkoutPage({Key? key}) : super(key: key);

  @override
  State<DownloadWorkoutPage> createState() => _DownloadWorkoutPageState();
}

class _DownloadWorkoutPageState extends State<DownloadWorkoutPage> {
  final _urlController = TextEditingController();   //input field for url only
  WorkoutPlan? _downloadedWorkoutPlan;
  String? _errorMessage;

  //this function fetches the workout plan from the json file
  Future<void> _fetchWorkoutPlan() async {
    setState(() {
      _downloadedWorkoutPlan = null;
      _errorMessage = null;
    });

    final url = _urlController.text;

    try {
      final response = await http.get(Uri.parse(url));  //this will parse the response from the url

      if (response.statusCode == 200) {
        final data = json.decode(response.body);  //this will decode the json file into format below

        final workoutPlan = WorkoutPlan(
          name: data['name'],
          exercises: (data['exercises'] as List).map((exercise) {
            final unitString = exercise['unit'] ?? 'repetitions';  // Default to repetitions if unit is missing
            return Exercise(
              name: exercise['name'],
              targetoutput: int.tryParse(exercise['target'].toString()) ?? 0,
              unit: _parseMeasurementUnit(unitString),
            );
          }).toList(),
        );

        setState(() {
          _downloadedWorkoutPlan = workoutPlan;
        });
      } else {
        setState(() {
          _errorMessage = 'Failed to fetch workout plan. Please check the URL.';  //shows this message if failed to fetch the url
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'An error occurred: $e';  //this will show an error message that could occur
      });
    }
  }

  //this will parse the unit properly from the json file
  MeasurementUnit _parseMeasurementUnit(String unit) {
    switch (unit.toLowerCase()) {
      case 'seconds':
        return MeasurementUnit.seconds;
      case 'meters':
        return MeasurementUnit.meters;
      case 'repetitions':
      default:
        return MeasurementUnit.repetitions;
    }
  }

  //this will save the workout plan in the hive box and will show snackbar after saving workout plan
  Future<void> _saveWorkoutPlan() async {
    if (_downloadedWorkoutPlan != null) {
      final workoutPlanBox = await Hive.openBox<WorkoutPlan>('workoutPlans');
      await workoutPlanBox.add(_downloadedWorkoutPlan!);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Workout plan saved successfully!')),
      );
      _urlController.clear(); //will clear the input field for url after saving or discarding workout plan
      setState(() {
        _downloadedWorkoutPlan = null;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Download Workout Plan')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _urlController,
              decoration: const InputDecoration(
                labelText: 'Workout Plan URL',
                hintText: 'Enter the URL of the workout plan',
              ),
              keyboardType: TextInputType.url,
            ),
            const SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: _fetchWorkoutPlan,
              child: const Text('Download Workout Plan'),
            ),
            const SizedBox(height: 16.0),
            if (_errorMessage != null)
              Text(
                _errorMessage!,
                style: const TextStyle(color: Colors.red),
              ),
            if (_downloadedWorkoutPlan != null)   //this will show the workout plan from json file in proper format
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Workout Plan: ${_downloadedWorkoutPlan!.name}',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0),
                    ),
                    const SizedBox(height: 8.0),
                    const Text('Exercises:'),
                    ..._downloadedWorkoutPlan!.exercises.map((exercise) {
                      return Text(
                        '${exercise.name} - Target: ${exercise.targetoutput} ${exercise.unit.displayName}',
                      );
                    }).toList(),
                    const SizedBox(height: 16.0),
                    ElevatedButton(
                      onPressed: _saveWorkoutPlan,    //button for saving workout plan
                      child: const Text('Save Workout Plan'),
                    ),
                    TextButton(
                      onPressed: () {
                        setState(() {
                          _downloadedWorkoutPlan = null;
                        });
                      },
                      child: const Text('Discard'),   //this can discard that plan
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}