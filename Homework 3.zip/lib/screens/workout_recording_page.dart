import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/models.dart';
import '../providers/workout_provider.dart';
import '../widgets/recent_performance_widget.dart';
import 'dart:async';

//a widget which allows user to record workouts
class WorkoutRecordingPage extends StatefulWidget {
  final WorkoutPlan workoutPlan;

  const WorkoutRecordingPage({Key? key, required this.workoutPlan}) : super(key: key);

  @override
  State<WorkoutRecordingPage> createState() => _WorkoutRecordingPageState();
}

class _WorkoutRecordingPageState extends State<WorkoutRecordingPage> {
  //this stores at results of each exercise
  final Map<Exercise, int> _exerciseResults = {};
  //store stopwatch instances for time based exercises
  final Map<Exercise, Stopwatch> _stopwatches = {};

  @override
  void initState() {
    super.initState();
    //initialize results and stopwatches for each exercise
    for (var exercise in widget.workoutPlan.exercises) {
      _exerciseResults[exercise] = 0;
      if (exercise.unit == MeasurementUnit.seconds) {
        _stopwatches[exercise] = Stopwatch();
      }
    }
  }

  //this functions submits the workout and also convert them to list
  void _submitWorkout() {
    final results = _exerciseResults.entries.map((entry) {
      return ExerciseResult(exercise: entry.key, actualoutput: entry.value);
    }).toList();

    final workout = Workout(date: DateTime.now(), results: results);

    // Add to Hive through WorkoutProvider
    Provider.of<WorkoutProvider>(context, listen: false).addWorkout(workout);

    Navigator.pop(context, workout);
  }

  //widget to build exercise input according to units of each exercise
  Widget _buildExerciseInput(Exercise exercise) {
    switch (exercise.unit) {
      case MeasurementUnit.repetitions:
        return _buildStepperInput(exercise);
      case MeasurementUnit.seconds:
        return _buildStopwatchInput(exercise);
      case MeasurementUnit.meters:
        return _buildSliderInput(exercise);
      }
  }

  //Stepper Input for Repetitions based exercises which has + and - buttons
  Widget _buildStepperInput(Exercise exercise) {
    return ListTile(
      key: Key('${exercise.name}'),
      title: Text('${exercise.name} (Target: ${exercise.targetoutput} repetitions)'),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            key: Key('remove_${exercise.name}'),
            icon: const Icon(Icons.remove),
            onPressed: () {
              setState(() {
                _exerciseResults[exercise] = (_exerciseResults[exercise]! - 1).clamp(0, 999);
              });
            },
          ),
          Text('${_exerciseResults[exercise]}'),
          IconButton(
            key: Key('add_${exercise.name}'),
            icon: const Icon(Icons.add),
            onPressed: () {
              setState(() {
                _exerciseResults[exercise] = (_exerciseResults[exercise]! + 1).clamp(0, 999);
              });
            },
          ),
        ],
      ),
    );
  }

  //Stopwatch Input for Time-based Exercises and provides start stop functionality

  Widget _buildStopwatchInput(Exercise exercise) {
    return ListTile(
      title: Text('${exercise.name} (Target: ${exercise.targetoutput} seconds)'),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          ElevatedButton(
            key: Key('${exercise.name}'),
            onPressed: () {
              setState(() {
                if (_stopwatches[exercise]!.isRunning) {
                  _stopwatches[exercise]!.stop();
                  _timer?.cancel();  // Stop the timer
                  _exerciseResults[exercise] = _stopwatches[exercise]!.elapsed.inSeconds;
                } else {
                  _stopwatches[exercise]!.reset();
                  _stopwatches[exercise]!.start();
                  _startTimer(exercise);  // Start updating the UI
                }
              });
            },
            child: Text(_stopwatches[exercise]!.isRunning ? 'Stop' : 'Start'),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text('${_exerciseResults[exercise] ?? 0} sec'),
          ),
        ],
      ),
    );
  }

  Timer? _timer;

  //function for showing the time continuously
  void _startTimer(Exercise exercise) {
    _timer?.cancel();  // Cancel any existing timer
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_stopwatches[exercise]!.isRunning) {
        setState(() {
          _exerciseResults[exercise] = _stopwatches[exercise]!.elapsed.inSeconds;
        });
      } else {
        _timer?.cancel();
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();  // Cancel the timer when the widget is disposed
    super.dispose();
  }

  //Slider Input for Distance-based Exercises and provides a slider to input exercise input in meters
  Widget _buildSliderInput(Exercise exercise) {
    return Column(
      children: [
        Text('${exercise.name} (Target: ${exercise.targetoutput} meters)'),
        Slider(
          key: Key('${exercise.name}'),
          value: _exerciseResults[exercise]!.toDouble(),
          min: 0,
          max: exercise.targetoutput.toDouble() * 1.5,
          divisions: 50,
          label: '${_exerciseResults[exercise]} meters',
          onChanged: (value) {
            setState(() {
              _exerciseResults[exercise] = value.toInt();
            });
          },
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.workoutPlan.name)),
      body: Column(
        children: [
          Expanded(
            //main list of exercise inputs
            child: ListView(
              children: widget.workoutPlan.exercises.map(_buildExerciseInput).toList(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(0.0),
            child: ElevatedButton(
              key: const Key('submit_workout_button'),
              onPressed: _submitWorkout,
              child: const Text('Finish Workout'),
            ),
          ),
          const RecentPerformanceWidget(),
        ],
      ),
    );
  }
}