import 'package:flutter/material.dart';
import 'package:project_1/screens/workout_plan_selector.dart';
import 'package:provider/provider.dart';
import '../providers/workout_provider.dart';
import '../widgets/recent_performance_widget.dart';
import '../widgets/workout_card.dart';
import 'workout_recording_page.dart';

//this widget is the homepage of app and will show the list of workouts that are completed and download button on top right corner
class WorkoutHistoryPage extends StatefulWidget {
  const WorkoutHistoryPage({Key? key}) : super(key: key);

  @override
  State<WorkoutHistoryPage> createState() => _WorkoutHistoryPageState();
}

class _WorkoutHistoryPageState extends State<WorkoutHistoryPage> {
  @override
  Widget build(BuildContext context) {
    final workoutProvider = Provider.of<WorkoutProvider>(context);  //fetching the workout provider here
    final workouts = workoutProvider.workouts;    //this is for all workouts

    return Scaffold(
      appBar: AppBar(
        title: const Text('Workout History'),
        backgroundColor: Colors.red,
        actions: [
          IconButton(       //this is the download button
            icon: const Icon(Icons.download, color: Colors.white),
            tooltip: 'Download Workout Plan',
            onPressed: () {
              Navigator.pushNamed(context, '/downloadWorkout');   //navigate to download workout plan
            },
          ),
        ],
      ),
      body: Column(
        children: [
          const RecentPerformanceWidget(),   //will show recent performance widget at the top
          Expanded(
            child: workouts.isEmpty
                ? const Center(
              child: Text(
                'No workouts recorded yet.\nTap the "+" button to start a new workout.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16.0, color: Colors.grey),
              ),
            )
                : ListView.builder(
              itemCount: workouts.length,
              itemBuilder: (context, index) {
                final workout = workouts[index];
                return WorkoutCard(
                  workout: workout,
                  onTap: () {
                    Navigator.pushNamed(
                      context,
                      '/workoutDetails',
                      arguments: workout,
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(   //button for starting the workout and this will show the saved workout plans
        backgroundColor: Colors.white70,
        onPressed: () async {
          final selectedPlan = await WorkoutPlanSelector.show(context);

          if (selectedPlan != null) {
            final newWorkout = await Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => WorkoutRecordingPage(workoutPlan: selectedPlan),    //this will navigate to workoutrecordingpage with selected plan
              ),
            );

            if (newWorkout != null) {
              workoutProvider.addWorkout(newWorkout);
            }
          }
        },
        tooltip: 'Start New Workout',
        child: const Icon(Icons.add),
      ),
    );
  }
}