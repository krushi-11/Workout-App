import 'package:flutter/material.dart';
import '../models/models.dart';
import '../widgets/recent_performance_widget.dart';

//This is the page to show details of the workout and also the exercises which are successful or not
class WorkoutDetailsPage extends StatelessWidget {
  //the workout to display details for
  final Workout workout;

  //here is the constructor which requires the data from the workout
  const WorkoutDetailsPage({super.key, required this.workout});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: const Text('Workout Details'),
      ),
      //main area here and it is scrollable view
      body: Column(
        children: [
          const RecentPerformanceWidget(),
          Expanded(
            child: ListView.builder(
              itemCount: workout.results.length,
              itemBuilder: (context, index) {
                //here it will extract the exercise data for the selected workout
                final result = workout.results[index];
                final exercise = result.exercise;
                final isSuccessful = result.isSuccessful;

                //here is the full styling and decoration of UI
                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                  elevation: 4.0,
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(16.0),
                    //added some icons for better UI
                    leading: Icon(
                      isSuccessful ? Icons.check_circle : Icons.cancel,
                      color: isSuccessful ? Colors.green : Colors.red,
                      size: 40.0,
                    ),
                    //this will show the name of exercise
                    title: Text(
                      exercise.name,
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0),
                    ),
                    //this will show the comparison of outputs which is done by user and what is actually the target
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        //here they will check targetoutput and actualoutput and also mark with red and green according to that
                        Text(
                          'Target: ${exercise.targetoutput} ${exercise.unit.displayName}',
                          style: const TextStyle(fontSize: 14.0, color: Colors.black54),
                        ),
                        Text(
                          'Achieved: ${result.actualoutput} ${exercise.unit.displayName}',
                          style: TextStyle(
                            fontSize: 14.0,
                            color: isSuccessful ? Colors.green : Colors.red,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}