import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import '../models/fake_data.dart';
import '../models/models.dart';

//this widget is for selecting the workout plan that are downloaded and the hardcoded plan as well
class WorkoutPlanSelector {
  static Future<WorkoutPlan?> show(BuildContext context) async {
    final workoutPlanBox = await Hive.openBox<WorkoutPlan>('workoutPlans');   //will show the plans from box that are saved
    final savedPlans = workoutPlanBox.values.toList();

    final allPlans = [exampleWorkoutPlan, ...savedPlans]; // Include the hardcoded plan

    //this shows the dialogue box containing saved workoutplans
    return showDialog<WorkoutPlan>(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text('Select a Workout Plan'),
              content: SizedBox(
                width: double.maxFinite,
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: allPlans.length,
                  itemBuilder: (context, index) {
                    final plan = allPlans[index];

                    return Card(    //card for each plan
                      margin: const EdgeInsets.symmetric(vertical: 8.0),
                      child: ListTile(
                        title: Text(plan.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ...plan.exercises.map((exercise) {
                              return Text(
                                '- ${exercise.name} (Target: ${exercise.targetoutput} ${exercise.unit.displayName})',
                              );
                            }).toList(),
                          ],
                        ),
                        onTap: () {
                          Navigator.of(context).pop(plan); // Return the selected plan
                        },
                        trailing: index == 0
                            ? null // Don't show a delete icon for the hardcoded plan
                            : IconButton(   //delete button for all other plans
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () async {
                            await workoutPlanBox.deleteAt(index - 1); // Delete from Hive
                            setState(() {
                              allPlans.removeAt(index);
                            });
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Workout plan deleted successfully!')),
                            );
                          },
                        ),
                      ),
                    );
                  },
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(null),
                  child: const Text('Cancel'),
                ),
              ],
            );
          },
        );
      },
    );
  }
}