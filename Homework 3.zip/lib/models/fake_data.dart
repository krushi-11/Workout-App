import 'models.dart';

//hard coded workout plan which will be used to record the workouts
final exampleWorkoutPlan = WorkoutPlan(
  name: "Full Body Workout",
  exercises: [
    Exercise(name: 'Push Ups', targetoutput: 20, unit: MeasurementUnit.repetitions),
    Exercise(name: 'Plank', targetoutput: 60, unit: MeasurementUnit.seconds),
    Exercise(name: 'Running', targetoutput: 1000, unit: MeasurementUnit.meters),
    Exercise(name: 'Jumping Jacks', targetoutput: 30, unit: MeasurementUnit.repetitions),
    Exercise(name: 'Squats', targetoutput: 15, unit: MeasurementUnit.repetitions),
    Exercise(name: 'Cycling', targetoutput: 5000, unit: MeasurementUnit.meters),
    Exercise(name: 'Burpees', targetoutput: 10, unit: MeasurementUnit.repetitions),
  ],
);