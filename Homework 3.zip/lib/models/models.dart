import 'package:hive/hive.dart';
part 'models.g.dart';    //this is required to generate models.g.dart which will be used for hive

// Enum representing different types of units of measurement for exercises
@HiveType(typeId: 0)
enum MeasurementUnit {
  @HiveField(0)
  seconds,

  @HiveField(1)
  repetitions,

  @HiveField(2)
  meters,
}

// This function converts the enum value to a user-friendly string
extension MeasurementUnitExtension on MeasurementUnit {
  String get displayName {
    switch (this) {
      case MeasurementUnit.seconds:
        return 'seconds';
      case MeasurementUnit.repetitions:
        return 'repetitions';
      case MeasurementUnit.meters:
        return 'meters';
    }
  }
}

// Exercise class
@HiveType(typeId: 1)
class Exercise {
  @HiveField(0)
  final String name;

  @HiveField(1)
  final int targetoutput;

  @HiveField(2)
  final MeasurementUnit unit;

  Exercise({required this.name, required this.targetoutput, required this.unit});
}

//Exercise Result class
@HiveType(typeId: 2)
class ExerciseResult {
  @HiveField(0)
  final Exercise exercise;

  @HiveField(1)
  final int actualoutput;

  ExerciseResult({required this.exercise, required this.actualoutput});

  bool get isSuccessful => actualoutput >= exercise.targetoutput;
}

//workout class
@HiveType(typeId: 3)
class Workout {
  @HiveField(0)
  final DateTime date;

  @HiveField(1)
  final List<ExerciseResult> results;

  Workout({required this.date, required this.results});
}

// WorkoutPlan class
@HiveType(typeId: 4)
class WorkoutPlan {
  @HiveField(0)
  final String name;

  @HiveField(1)
  final List<Exercise> exercises;

  WorkoutPlan({required this.name, required this.exercises});
}