import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import '../models/models.dart';

class WorkoutProvider with ChangeNotifier {
  //A hive box for storing the data like workouts and workout plans
  final Box<Workout> _workoutBox;

  // Constructor that allows passing a custom box for only testing purpose
  WorkoutProvider([Box<Workout>? customBox])
      : _workoutBox = customBox ?? Hive.box<Workout>('workouts');

  //List for getting the workouts and storing it into box in list
  List<Workout> get workouts => _workoutBox.values.toList();

  //add workout function and it checks for duplicates as well
  void addWorkout(Workout workout) {
    if (!_workoutBox.values.contains(workout)) {
      _workoutBox.add(workout);
      notifyListeners(); //its notifying the provider about the change in data
    }
  }

  //This is for recent performance widget to get the stats from last 7 days
  List<Workout> getRecentWorkouts() {
    return workouts.where((w) => w.date.isAfter(DateTime.now().subtract(Duration(days: 7)))).toList();
  }
}