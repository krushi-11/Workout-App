import 'package:flutter/material.dart';
import 'package:project_1/screens/download_workout_plan_page.dart';
import 'package:provider/provider.dart';
import 'providers/workout_provider.dart';
import 'screens/workout_history_page.dart';
import 'screens/workout_details_page.dart';
import 'models/models.dart';
import 'package:hive_flutter/hive_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();   //this will initialize the hive

  //this will initialize all the adapters here
  Hive.registerAdapter(WorkoutAdapter());
  Hive.registerAdapter(ExerciseResultAdapter());
  Hive.registerAdapter(ExerciseAdapter());
  Hive.registerAdapter(MeasurementUnitAdapter());
  Hive.registerAdapter(WorkoutPlanAdapter());

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: Hive.openBox<Workout>('workouts'),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          if (snapshot.hasError) {
            return const MaterialApp(
              home: Scaffold(
                body: Center(child: Text('Failed to open Hive box.')),
              ),
            );
          } else {
            return ChangeNotifierProvider(
              create: (_) => WorkoutProvider(),
              child: MaterialApp(
                title: 'Workout Tracker',
                theme: ThemeData(primarySwatch: Colors.blue),
                initialRoute: '/',
                routes: {
                  '/': (context) => const WorkoutHistoryPage(),   //navigate to workout history page
                  '/workoutDetails': (context) => WorkoutDetailsPage(   //navigate to workout details page
                    workout: ModalRoute.of(context)!.settings.arguments as Workout,
                  ),
                  '/downloadWorkout': (context) => const DownloadWorkoutPage(),   //navigate to download workout plan page
                },
              ),
            );
          }
        } else {
          return const MaterialApp(
            home: Scaffold(
              body: Center(child: CircularProgressIndicator()),
            ),
          );
        }
      },
    );
  }
}